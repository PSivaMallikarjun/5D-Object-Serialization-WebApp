function project5DTo3D(x, y, z, w, v) {
    let projectedX = x + 0.2 * w + 0.1 * v;
    let projectedY = y + 0.2 * w + 0.1 * v;
    let projectedZ = z + 0.2 * w + 0.1 * v;
    return { projectedX, projectedY, projectedZ };
}

function generateObject() {
    let shape = document.getElementById("shape").value;
    let x = parseFloat(document.getElementById("x").value) || 0;
    let y = parseFloat(document.getElementById("y").value) || 0;
    let z = parseFloat(document.getElementById("z").value) || 0;
    let w = parseFloat(document.getElementById("w").value) || 0;
    let v = parseFloat(document.getElementById("v").value) || 0;

    let { projectedX, projectedY, projectedZ } = project5DTo3D(x, y, z, w, v);

    document.getElementById("scene-container").innerHTML = ""; // Clear previous render

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer();
    renderer.setSize(500, 400);
    document.getElementById("scene-container").appendChild(renderer.domElement);

    let geometry;
    if (shape === "cube") {
        geometry = new THREE.BoxGeometry(1, 1, 1);
    } else if (shape === "sphere") {
        geometry = new THREE.SphereGeometry(0.5, 32, 32);
    }

    const material = new THREE.MeshBasicMaterial({ color: 0xff0000, wireframe: true });
    const object = new THREE.Mesh(geometry, material);
    object.position.set(projectedX, projectedY, projectedZ);

    scene.add(object);
    camera.position.z = 3;

    function animate() {
        requestAnimationFrame(animate);
        object.rotation.x += 0.01;
        object.rotation.y += 0.01;
        renderer.render(scene, camera);
    }
    animate();
}
